# Keyed AST Watermarking for AI-Generated Python Code

This repository contains the final version of the CS 763 Trustworthy AI project on keyed AST watermarking for Python code.

## What is in this repo

- `src/benchmark.py` - 22 Python benchmark tasks and their tests
- `src/watermark.py` - AST watermark, token baseline, and detectors
- `src/attacks.py` - semantics-preserving edit attacks
- `src/evaluate.py` - main evaluation script
- `tests/test_watermark.py` - unit tests
- `results/` - CSV files, JSON output, and figures from the final run
- `docs/final_report.md` - simple markdown version of the final report
- `artifacts/` - report, poster, and poster script deliverables

## Final AST feature families

The final AST watermark uses 7 feature families:

1. comparison direction  
2. constant side  
3. update form  
4. membership container  
5. return-if / ternary return  
6. return_bool  
7. neq_form  

## Final experiment setup

- tasks: 22
- secret keys: 20
- AST feature locations: 61
- attacks: 15

## How to reproduce the results

From the repository root, run:

```bash
PYTHONPATH=src python src/evaluate.py
```

This writes:

- `results/final_summary.csv`
- `results/final_results.json`
- `results/sample_size.csv`
- `results/per_task_features.csv`
- `results/final_*.png`

## How to run the tests

```bash
PYTHONPATH=src python -m unittest discover -s tests -v
```

## Main result in one sentence

The AST watermark stays reliable under ordinary edits like renaming and dead-code insertion, while the token baseline fails under rename, but the AST watermark still breaks under strong adaptive normalization.
