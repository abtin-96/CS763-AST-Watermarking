# Keyed AST Watermarking for AI-Generated Python Code

CS 763 Trustworthy AI - Final Report  
Abtin Afshar (abtin@cs.wisc.edu)

## 1. Project goal

The goal of this project is to study whether a watermark for AI-generated code can be hidden in the **program structure** instead of only in surface-level tokens such as variable names. The main hope is that an AST-based watermark will survive ordinary edits like formatting, renaming, and small refactoring steps better than a token-based watermark.

The main question is:

**Can a lightweight keyed AST watermark for Python code stay detectable after common semantics-preserving edits?**

This final version keeps the same basic idea from the earlier phases, but it adds a few small improvements and rewrites the documentation in a simpler style.

## 2. Where Phase 2 left off

Phase 2 used a small prototype with three AST feature families:

- comparison direction
- constant side for equality
- update form

That version already showed the main pattern. The AST watermark survived formatting and variable renaming, while the token baseline broke under renaming. But the Phase 2 system still failed under a strong adaptive attack that normalized the same AST choices used for the watermark.

In the final phase, I kept the same overall design and made small changes instead of redesigning the whole system.

## 3. What changed in the final phase

This final version makes four main changes.

First, I kept the earlier Phase 3 addition of **membership container form**. This means the old four structural features from the intermediate final prototype are:

- comparison direction
- constant side
- update form
- membership container

Second, I added **three more features** with only small code changes. The final system now uses **7 AST feature families** in total:

1. **comparison direction**  
   `x < y` vs `y > x`

2. **constant side**  
   `x == 0` vs `0 == x`

3. **update form**  
   `x = x + y` vs `x += y`

4. **membership container**  
   `x in (a, b)` vs `x in [a, b]`

5. **return-if / ternary return**  
   `if cond: return a else: return b` vs `return a if cond else b`

6. **return_bool**  
   `return True` vs `return not False`, and similarly for `False`

7. **neq_form**  
   `x != y` vs `not x == y`

Third, I expanded the benchmark from **20 tasks to 22 tasks** by adding two short tasks with `!=` patterns. This gives better coverage for the new `neq_form` feature.

Fourth, I kept the stronger attack set and the multi-channel detector from the polished version, because those were useful improvements and still fit the same small project.

## 4. Final technical approach

### 4.1 Embedding

The embedder parses a Python function into an AST and looks for places where there are two equivalent ways to write the same logic. A secret key decides which form should appear at each location.

For example, if the key wants bit 1 at a given location, the code may be rewritten from

```python
if cond:
    return a
else:
    return b
```

to

```python
return a if cond else b
```

The same idea is used for all seven feature families.

### 4.2 Detection

The detector parses the code again, extracts the same feature locations, and checks whether the observed forms agree with the keyed pattern more often than chance would suggest.

I use two detectors:

- an **aggregate detector**, which pools all AST feature matches together
- a **multi-channel detector**, which also checks each feature family separately

Both are simple binomial-style detectors.

### 4.3 Baseline

For comparison, I still keep the token baseline from the earlier phases. It stores the watermark in local variable names. This baseline is intentionally simple and is mostly there to show the difference between token-level and structure-level signals.

## 5. Benchmark and attack setup

The final experiment uses:

- **22 Python tasks**
- **20 secret keys**
- **61 total watermarkable AST locations**
- **15 attacks**

The 61 AST locations are split across the seven feature families as follows:

- comparison direction: 18
- constant side: 3
- update form: 22
- membership container: 5
- return-if / ternary return: 1
- return_bool: 6
- neq_form: 6

The attacks are grouped into three kinds.

### 5.1 Surface attacks

These are ordinary edits that a user might make while cleaning up generated code:

- format
- rename
- dead_code
- combined_weak

### 5.2 Single-family normalization attacks

These attacks normalize one AST feature family at a time:

- normalize_cmp_only
- normalize_const_only
- normalize_aug_only
- normalize_in_only
- normalize_return_only
- normalize_bool_only
- normalize_neq_only

### 5.3 Strong adaptive attacks

These attacks try to scrub almost all or all of the AST signal:

- normalize_six_of_seven
- ast_normalize
- combined_strong

## 6. Final results

### 6.1 Correctness

All watermarked code still passed its tests after watermarking and after all attacks in this benchmark run.

So the final correctness rate on the benchmark is:

- **AST watermark:** 100%
- **Token baseline:** 100%

### 6.2 Main detection results

The most important rows from the final table are below.

| Scheme | Attack | TPR | FPR | Average match rate |
|---|---|---:|---:|---:|
| AST | clean | 1.00 | 0.00 | 1.00 |
| AST | rename | 1.00 | 0.00 | 1.00 |
| AST | dead_code | 1.00 | 0.00 | 1.00 |
| AST | combined_weak | 1.00 | 0.00 | 1.00 |
| AST | ast_normalize | 0.00 | 0.00 | 0.52 |
| AST | combined_strong | 0.00 | 0.00 | 0.52 |
| Token | rename | 0.00 | 0.00 | 0.00 |
| Token | combined_weak | 0.00 | 0.00 | 0.00 |

The main message is the same as before, but now it is supported by a richer feature family.

The AST watermark stays at **TPR = 1.00** under the ordinary edit attacks: clean, format, rename, dead code insertion, and combined weak edits. The token baseline still fails under renaming and under the weak combined attack, because its signal lives in variable names.

At the same time, the strong adaptive attacks still defeat the AST watermark. Under `ast_normalize` and `combined_strong`, the AST detector falls to chance level.

### 6.3 What the single-family attacks show

The single-family normalization attacks help explain where the robustness comes from.

For every attack that removes only **one** feature family, the AST watermark still detects perfectly in this run:

- normalize_cmp_only: TPR = 1.00
- normalize_const_only: TPR = 1.00
- normalize_aug_only: TPR = 1.00
- normalize_in_only: TPR = 1.00
- normalize_return_only: TPR = 1.00
- normalize_bool_only: TPR = 1.00
- normalize_neq_only: TPR = 1.00

This means the final system has enough redundancy that removing one channel is not enough to hide the watermark.

But when the attacker removes **six of the seven** channels, detection fails:

- normalize_six_of_seven: TPR = 0.00
- average match rate = 0.55

So the final system is stronger than the earlier versions against partial scrubbing, but it still has the same basic ceiling against a strong attacker who knows the feature family.

### 6.4 Corpus size

The sample-size experiment still shows the same transition as before.

With 1 or 2 short functions, detection is weak.  
At **3 functions**, it becomes moderately reliable.  
By **5 functions**, detection is already perfect in this benchmark run under clean, rename, and combined weak attacks.

This means the watermark is more meaningful for a **small body of code** than for a very short snippet.

## 7. What the new features helped with

The three new features were chosen because they fit naturally into the same keyed rewrite framework and only needed small code changes.

- **return-if / ternary return** adds a real control-flow style feature instead of another comparison flip.
- **return_bool** gives a tiny extra channel in boolean-heavy tasks.
- **neq_form** is a useful new feature because `!=` appears naturally in common Python code and can be rewritten to `not x == y` with the same meaning.

Among these three, `neq_form` helped the most right away, because the benchmark now has **6 neq sites**. The `return_bool` feature also added **6 sites**. The `return_ternary` channel is still small in this benchmark, with only **1 site**, so it is more of a modest extra feature than a major source of detection power.

That is consistent with the goal of this revision: small improvements, not a new system.

## 8. Honest limitations

This project still has some clear limitations.

First, the benchmark is still hand-written. I did not evaluate on real code LLM outputs in the final version.

Second, some feature channels are still small. In particular, the `return_ternary` channel only has one location in this benchmark, and the `const_side` channel only has three.

Third, the overall limitation from the earlier phases is still true: if an attacker knows the finite feature family and explicitly normalizes it, the watermark can be scrubbed.

So the right conclusion is **not** that AST watermarking solves code provenance completely. The more honest conclusion is that a small post-processing structural watermark is clearly more stable than a token watermark under ordinary edits, but it still loses to a strong adaptive normalizer.

## 9. Conclusion

The final version of the project supports the same basic story as the earlier phases, but in a more complete way.

- The feature family grew from the 3 features in Phase 2 to **7 total features** in the final system.
- The benchmark grew to **22 tasks**.
- The attack set grew to **15 attacks**.
- The AST watermark stayed strong under ordinary semantics-preserving edits.
- The token baseline still failed under renaming.
- Strong adaptive normalization remained the central obstacle.

So the final conclusion is:

**Program structure is a better place to hide a watermark than variable names, but a small hand-designed AST watermark is still not enough against a determined attacker who explicitly normalizes the same feature family.**

## References

[1] Kirchenbauer et al., *A Watermark for Large Language Models*, 2023.  
[2] Zhao et al., *SoK: Watermarking for AI-Generated Content*, 2024.  
[3] Suresh et al., *Is the Watermarking of LLM-Generated Code Robust?*, 2024.  
[4] Li et al., *Efficient and Universal Watermarking for LLM-Generated Code Detection*, 2024.  
[5] Kim et al., *Marking Code Without Breaking It*, 2025.  
[6] Zhang et al., *Robust and Secure Code Watermarking via ML/Crypto Codesign*, 2025.  
[7] Javidnia et al., *SWaRL*, 2026.
