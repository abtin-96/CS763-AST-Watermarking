"""Semantics-preserving editing attacks for the code-watermark prototype."""
from __future__ import annotations

import ast
from typing import Callable

from watermark import _reverse_cmp, _is_const, _pure_literal_container, _simple_return_pair, _bool_return_form, _make_bool_return, _neq_form_bit


def format_code(code: str) -> str:
    return ast.unparse(ast.parse(code))


class LocalCollector(ast.NodeVisitor):
    def __init__(self):
        self.names: list[str] = []
        self.seen: set[str] = set()

    def _add(self, name: str) -> None:
        if name not in self.seen and name != "solve":
            self.seen.add(name)
            self.names.append(name)

    def visit_arg(self, node: ast.arg) -> None:
        self._add(node.arg)

    def visit_Name(self, node: ast.Name) -> None:
        if isinstance(node.ctx, (ast.Load, ast.Store)):
            self._add(node.id)


BUILTINS = {"range", "len", "abs", "min", "max", "sum", "True", "False"}


class Renamer(ast.NodeTransformer):
    def __init__(self, mapping: dict[str, str]):
        self.mapping = mapping

    def visit_arg(self, node: ast.arg) -> ast.AST:
        if node.arg in self.mapping:
            node.arg = self.mapping[node.arg]
        return node

    def visit_Name(self, node: ast.Name) -> ast.AST:
        if node.id in self.mapping:
            node.id = self.mapping[node.id]
        return node


def rename_variables(code: str) -> str:
    tree = ast.parse(code)
    coll = LocalCollector()
    coll.visit(tree)
    names = [n for n in coll.names if n not in BUILTINS]
    mapping = {name: f"v{idx}" for idx, name in enumerate(names)}
    out = Renamer(mapping).visit(tree)
    ast.fix_missing_locations(out)
    return ast.unparse(out)


class DeadCodeInserter(ast.NodeTransformer):
    def visit_FunctionDef(self, node: ast.FunctionDef) -> ast.AST:
        self.generic_visit(node)
        dead = ast.If(test=ast.Constant(value=False), body=[ast.Pass()], orelse=[])
        node.body.insert(0, dead)
        return node


def insert_dead_code(code: str) -> str:
    tree = ast.parse(code)
    out = DeadCodeInserter().visit(tree)
    ast.fix_missing_locations(out)
    return ast.unparse(out)


class ASTNormalizer(ast.NodeTransformer):
    def __init__(self, do_cmp=True, do_const=True, do_aug=True, do_in=True, do_ret=True, do_bool=True, do_neq=True):
        self.do_cmp = do_cmp
        self.do_const = do_const
        self.do_aug = do_aug
        self.do_in = do_in
        self.do_ret = do_ret
        self.do_bool = do_bool
        self.do_neq = do_neq

    def visit_If(self, node: ast.If) -> ast.AST:
        pair = _simple_return_pair(node)
        if self.do_ret and pair is not None:
            test, left, right = pair
            node.test = self.visit(test)
            node.body[0].value = self.visit(left)
            node.orelse[0].value = self.visit(right)
            return node
        self.generic_visit(node)
        return node

    def visit_Return(self, node: ast.Return) -> ast.AST:
        if self.do_bool:
            form = _bool_return_form(node)
            if form is not None:
                _, out_value = form
                return ast.copy_location(_make_bool_return(out_value, 0), node)

        if self.do_ret and isinstance(node.value, ast.IfExp):
            out = ast.If(
                test=node.value.test,
                body=[ast.Return(value=node.value.body)],
                orelse=[ast.Return(value=node.value.orelse)],
            )
            out.test = self.visit(out.test)
            out.body[0].value = self.visit(out.body[0].value)
            out.orelse[0].value = self.visit(out.orelse[0].value)
            return ast.copy_location(out, node)

        self.generic_visit(node)
        return node

    def visit_UnaryOp(self, node: ast.UnaryOp) -> ast.AST:
        self.generic_visit(node)
        if self.do_neq and _neq_form_bit(node) == 1:
            cmp = node.operand
            return ast.copy_location(ast.Compare(left=cmp.left, ops=[ast.NotEq()], comparators=cmp.comparators), node)
        return node

    def visit_Compare(self, node: ast.Compare) -> ast.AST:
        self.generic_visit(node)
        if len(node.ops) != 1 or len(node.comparators) != 1:
            return node
        left, op, right = node.left, node.ops[0], node.comparators[0]
        if self.do_in and isinstance(op, (ast.In, ast.NotIn)) and _pure_literal_container(right):
            if isinstance(right, ast.List):
                node.comparators[0] = ast.copy_location(ast.Tuple(elts=right.elts, ctx=ast.Load()), right)
            return node
        if self.do_neq and isinstance(op, ast.NotEq) and not _is_const(left) and not _is_const(right):
            return node
        if self.do_const and isinstance(op, (ast.Eq, ast.NotEq)) and (_is_const(left) ^ _is_const(right)):
            if _is_const(left):
                node.left, node.comparators[0] = right, left
            return node
        if self.do_cmp and isinstance(op, (ast.Gt, ast.GtE)):
            node.left, node.comparators[0] = right, left
            node.ops[0] = _reverse_cmp(op)
            return node
        return node

    def visit_AugAssign(self, node: ast.AugAssign) -> ast.AST:
        self.generic_visit(node)
        if self.do_aug and isinstance(node.target, ast.Name):
            rhs = ast.BinOp(left=ast.Name(id=node.target.id, ctx=ast.Load()), op=node.op, right=node.value)
            return ast.copy_location(ast.Assign(targets=[node.target], value=rhs), node)
        return node


def _normalize(code: str, **flags) -> str:
    tree = ast.parse(code)
    out = ASTNormalizer(**flags).visit(tree)
    ast.fix_missing_locations(out)
    return ast.unparse(out)


def normalize_ast_features(code: str) -> str:
    return _normalize(code)


def normalize_cmp_only(code: str) -> str:
    return _normalize(code, do_cmp=True, do_const=False, do_aug=False, do_in=False, do_ret=False, do_bool=False, do_neq=False)


def normalize_const_only(code: str) -> str:
    return _normalize(code, do_cmp=False, do_const=True, do_aug=False, do_in=False, do_ret=False, do_bool=False, do_neq=False)


def normalize_aug_only(code: str) -> str:
    return _normalize(code, do_cmp=False, do_const=False, do_aug=True, do_in=False, do_ret=False, do_bool=False, do_neq=False)


def normalize_in_only(code: str) -> str:
    return _normalize(code, do_cmp=False, do_const=False, do_aug=False, do_in=True, do_ret=False, do_bool=False, do_neq=False)


def normalize_return_only(code: str) -> str:
    return _normalize(code, do_cmp=False, do_const=False, do_aug=False, do_in=False, do_ret=True, do_bool=False, do_neq=False)


def normalize_bool_only(code: str) -> str:
    return _normalize(code, do_cmp=False, do_const=False, do_aug=False, do_in=False, do_ret=False, do_bool=True, do_neq=False)


def normalize_neq_only(code: str) -> str:
    return _normalize(code, do_cmp=False, do_const=False, do_aug=False, do_in=False, do_ret=False, do_bool=False, do_neq=True)


def normalize_six_of_seven(code: str) -> str:
    # Canonicalize everything except the smallest const_side channel.
    return _normalize(code, do_cmp=True, do_const=False, do_aug=True, do_in=True, do_ret=True, do_bool=True, do_neq=True)


def combined_weak(code: str) -> str:
    return format_code(rename_variables(insert_dead_code(code)))


def combined_strong(code: str) -> str:
    return normalize_ast_features(rename_variables(format_code(code)))


ATTACKS: dict[str, Callable[[str], str]] = {
    "clean": lambda c: c,
    "format": format_code,
    "rename": rename_variables,
    "dead_code": insert_dead_code,
    "combined_weak": combined_weak,
    "normalize_cmp_only": normalize_cmp_only,
    "normalize_const_only": normalize_const_only,
    "normalize_aug_only": normalize_aug_only,
    "normalize_in_only": normalize_in_only,
    "normalize_return_only": normalize_return_only,
    "normalize_bool_only": normalize_bool_only,
    "normalize_neq_only": normalize_neq_only,
    "normalize_six_of_seven": normalize_six_of_seven,
    "ast_normalize": normalize_ast_features,
    "combined_strong": combined_strong,
}
