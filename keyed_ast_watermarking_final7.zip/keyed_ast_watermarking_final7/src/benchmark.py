"""Small Python benchmark for the AST watermarking project.

Each task has one function named solve plus a deterministic test suite.
The code snippets are deliberately small but include common programming idioms:
loops, comparisons, arithmetic updates, and membership tests.
"""
from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, Any


@dataclass(frozen=True)
class Task:
    name: str
    prompt: str
    code: str
    tests: list[tuple[tuple[Any, ...], Any]]


TASKS: list[Task] = [
    Task(
        "sum_even",
        "Return the sum of the even integers in nums.",
        """
def solve(nums):
    total = 0
    for n in nums:
        if n % 2 == 0:
            total = total + n
    return total
""".strip(),
        [(([1, 2, 3, 4],), 6), (([2, 8, 5],), 10), (([],), 0), (([-2, 3, 6],), 4)],
    ),
    Task(
        "count_positive",
        "Count how many values are positive.",
        """
def solve(nums):
    count = 0
    for n in nums:
        if n > 0:
            count = count + 1
    return count
""".strip(),
        [(([1, -1, 0, 3],), 2), (([-5, -2],), 0), (([4, 5],), 2)],
    ),
    Task(
        "factorial",
        "Return n factorial.",
        """
def solve(n):
    ans = 1
    i = 1
    while i <= n:
        ans = ans * i
        i = i + 1
    return ans
""".strip(),
        [((0,), 1), ((1,), 1), ((5,), 120), ((7,), 5040)],
    ),
    Task(
        "gcd",
        "Return the greatest common divisor of a and b.",
        """
def solve(a, b):
    while b != 0:
        temp = b
        b = a % b
        a = temp
    return abs(a)
""".strip(),
        [((12, 18), 6), ((7, 3), 1), ((42, 14), 14), ((-24, 18), 6)],
    ),
    Task(
        "dot_product",
        "Return the dot product of xs and ys.",
        """
def solve(xs, ys):
    total = 0
    for i in range(len(xs)):
        total = total + xs[i] * ys[i]
    return total
""".strip(),
        [(([1, 2, 3], [4, 5, 6]), 32), (([0, 1], [5, 7]), 7), (([], []), 0)],
    ),
    Task(
        "clamp",
        "Clamp x to the interval [lo, hi].",
        """
def solve(x, lo, hi):
    if x < lo:
        return lo
    if x > hi:
        return hi
    return x
""".strip(),
        [((5, 0, 10), 5), ((-2, 0, 10), 0), ((12, 0, 10), 10)],
    ),
    Task(
        "common_prefix",
        "Return the common prefix of two strings.",
        """
def solve(a, b):
    i = 0
    out = ""
    while i != len(a) and i != len(b):
        if a[i] != b[i]:
            return out
        out = out + a[i]
        i = i + 1
    return out
""".strip(),
        [(('flower', 'flow'), 'flow'), (('dog', 'cat'), ''), (('abc', 'abd'), 'ab')],
    ),
    Task(
        "grade_bucket",
        "Return a coarse letter grade from a numeric score.",
        """
def solve(score):
    if score >= 90:
        return "A"
    if score >= 80:
        return "B"
    if score >= 70:
        return "C"
    return "D"
""".strip(),
        [((95,), 'A'), ((82,), 'B'), ((70,), 'C'), ((69,), 'D')],
    ),
    Task(
        "vowel_count",
        "Count vowels in a string.",
        """
def solve(s):
    count = 0
    for ch in s:
        if ch in ["a", "e", "i", "o", "u"]:
            count = count + 1
    return count
""".strip(),
        [(('hello',), 2), (('cryptography',), 2), (('',), 0), (('aeiou',), 5)],
    ),
    Task(
        "remove_small",
        "Return all numbers at least t.",
        """
def solve(nums, t):
    out = []
    for n in nums:
        if n >= t:
            out.append(n)
    return out
""".strip(),
        [(([1, 3, 5], 3), [3, 5]), (([0, -1, 2], 1), [2]), (([], 4), [])],
    ),
    Task(
        "alternating_sum",
        "Return nums[0] - nums[1] + nums[2] - ... .",
        """
def solve(nums):
    total = 0
    i = 0
    for n in nums:
        if i % 2 == 0:
            total = total + n
        else:
            total = total - n
        i = i + 1
    return total
""".strip(),
        [(([1, 2, 3, 4],), -2), (([10],), 10), (([],), 0)],
    ),
    Task(
        "is_sorted",
        "Return True if nums is nondecreasing.",
        """
def solve(nums):
    i = 1
    while i < len(nums):
        if nums[i] < nums[i - 1]:
            return False
        i = i + 1
    return True
""".strip(),
        [(([1, 2, 2, 5],), True), (([3, 2],), False), (([],), True), (([1],), True)],
    ),
    Task(
        "has_forbidden",
        "Return True if a string contains a forbidden character.",
        """
def solve(s):
    for ch in s:
        if ch in ["<", ">", "&"]:
            return True
    return False
""".strip(),
        [(('abc',), False), (('a<b',), True), (('x&y',), True)],
    ),
    Task(
        "bounded_sum",
        "Sum values in nums that lie in [lo, hi].",
        """
def solve(nums, lo, hi):
    total = 0
    for n in nums:
        if n >= lo and n <= hi:
            total = total + n
    return total
""".strip(),
        [(([1, 3, 5, 7], 3, 6), 8), (([-2, 0, 2], -1, 2), 2), (([], 0, 1), 0)],
    ),
    Task(
        "first_index",
        "Return the first index of target, or -1 if absent.",
        """
def solve(nums, target):
    i = 0
    while i < len(nums):
        if nums[i] == target:
            return i
        i = i + 1
    return -1
""".strip(),
        [(([4, 5, 6], 5), 1), (([1, 2], 3), -1), (([], 1), -1)],
    ),
    Task(
        "cap_total",
        "Add numbers, but cap the running total at cap.",
        """
def solve(nums, cap):
    total = 0
    for n in nums:
        total = total + n
        if total > cap:
            return cap
    return total
""".strip(),
        [(([1, 2, 3], 10), 6), (([5, 10], 8), 8), (([], 4), 0)],
    ),
    Task(
        "count_allowed",
        "Count characters that are in the allowed set.",
        """
def solve(s):
    count = 0
    for ch in s:
        if ch in ["a", "b", "c"]:
            count = count + 1
    return count
""".strip(),
        [(('abcxyz',), 3), (('zzz',), 0), (('cab',), 3)],
    ),
    Task(
        "sum_until_negative",
        "Sum numbers until the first negative number.",
        """
def solve(nums):
    total = 0
    for n in nums:
        if n < 0:
            return total
        total = total + n
    return total
""".strip(),
        [(([1, 2, -1, 5],), 3), (([3, 4],), 7), (([-1, 2],), 0)],
    ),
    Task(
        "all_small",
        "Return True if every value is below the limit.",
        """
def solve(nums, limit):
    for n in nums:
        if n >= limit:
            return False
    return True
""".strip(),
        [(([1, 2, 3], 5), True), (([1, 5], 5), False), (([], 1), True)],
    ),
    Task(
        "score_words",
        "Score words: +2 for good, -1 for bad, +0 otherwise.",
        """
def solve(words):
    score = 0
    for w in words:
        if w in ["good", "great"]:
            score = score + 2
        if w in ["bad", "poor"]:
            score = score - 1
    return score
""".strip(),
        [((['good', 'bad', 'ok'],), 1), ((['great', 'good'],), 4), ((['poor', 'x'],), -1)],
    ),
    Task(
        "different_signs",
        "Return True when a and b are different.",
        """
def solve(a, b):
    if a != b:
        return True
    else:
        return False
""".strip(),
        [((3, -1), True), ((-2, 4), True), ((5, 5), False), ((-3, -3), False)],
    ),
    Task(
        "count_mismatches",
        "Count positions where two strings differ.",
        """
def solve(a, b):
    i = 0
    count = 0
    while i < len(a) and i < len(b):
        if a[i] != b[i]:
            count = count + 1
        i = i + 1
    if len(a) != len(b):
        count = count + abs(len(a) - len(b))
    return count
""".strip(),
        [(("abc", "axc"), 1), (("abc", "abcde"), 2), (("", ""), 0), (("ab", "cd"), 2)],
    ),
]


def run_task_tests(code: str, task: Task) -> bool:
    namespace: dict[str, Any] = {}
    try:
        exec(compile(code, f"<{task.name}>", "exec"), namespace)
        solve: Callable[..., Any] = namespace["solve"]
        for args, expected in task.tests:
            got = solve(*args)
            if got != expected:
                return False
        return True
    except Exception:
        return False


def full_corpus() -> str:
    return "\n\n".join(task.code for task in TASKS)
