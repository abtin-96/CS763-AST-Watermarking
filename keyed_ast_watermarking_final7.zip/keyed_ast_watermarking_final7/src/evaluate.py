"""Run final experiments for the keyed AST watermarking project."""
from __future__ import annotations

import csv
import json
import random
from pathlib import Path
from statistics import mean

import matplotlib.pyplot as plt

from attacks import ATTACKS
from benchmark import TASKS, run_task_tests
from watermark import (
    FEATURE_TYPES,
    DetectionResult,
    binom_tail,
    detect_ast_watermark,
    detect_ast_watermark_multichannel,
    detect_token_watermark,
    embed_ast_watermark,
    embed_token_watermark,
    extract_ast_bits,
    extract_token_bits,
)

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
RESULTS.mkdir(exist_ok=True)

NUM_KEYS = 20
SECRETS = [f"final-key-{i:04d}" for i in range(NUM_KEYS)]
SCHEMES = {
    "AST": (embed_ast_watermark, detect_ast_watermark),
    "Token": (embed_token_watermark, detect_token_watermark),
}


# ---------------------------------------------------------------------------
# Building corpora and applying attacks.

def corpus_for_scheme(secret: str, scheme: str) -> list[str]:
    embedder = SCHEMES[scheme][0]
    # Per-task salt: in a realistic deployment each generated sample carries a
    # nonce. Using one global salt would couple feature labels across functions.
    return [embedder(task.code, f"{secret}|task:{i}") for i, task in enumerate(TASKS)]


def unwatermarked_corpus() -> list[str]:
    return [task.code for task in TASKS]


def apply_attack_to_corpus(corpus: list[str], attack_name: str) -> list[str]:
    attack = ATTACKS[attack_name]
    return [attack(code) for code in corpus]


def check_correctness(corpus: list[str]) -> bool:
    return all(run_task_tests(code, task) for code, task in zip(corpus, TASKS))


def detect_corpus(corpus: list[str], secret: str, scheme: str) -> DetectionResult:
    detector = SCHEMES[scheme][1]
    matches = 0
    total = 0
    for i, code in enumerate(corpus):
        res = detector(code, f"{secret}|task:{i}")
        matches += res.matches
        total += res.total
    p = binom_tail(matches, total)
    return DetectionResult(matches, total, matches / total if total else 0.0, p, p <= 0.01)


def detect_corpus_multichannel(corpus: list[str], secret: str) -> tuple[bool, dict[str, int], dict[str, int]]:
    """Aggregate the multichannel detector across a corpus, with task-specific salt."""
    matches_by_type = {t: 0 for t in FEATURE_TYPES}
    total_by_type = {t: 0 for t in FEATURE_TYPES}
    for i, code in enumerate(corpus):
        res = detect_ast_watermark_multichannel(code, f"{secret}|task:{i}")
        for t in FEATURE_TYPES:
            matches_by_type[t] += res["per_channel"][t]["matches"]
            total_by_type[t] += res["per_channel"][t]["total"]

    total = sum(total_by_type.values())
    matches = sum(matches_by_type.values())
    aggregate_p = binom_tail(matches, total)
    aggregate_detected = aggregate_p <= 0.01

    k = max(sum(1 for t in FEATURE_TYPES if total_by_type[t] > 0), 1)
    any_channel = False
    for t in FEATURE_TYPES:
        n = total_by_type[t]
        if n == 0:
            continue
        p = binom_tail(matches_by_type[t], n)
        if p <= 0.01 / k:
            any_channel = True

    return aggregate_detected or any_channel, matches_by_type, total_by_type


def count_features(corpus: list[str], scheme: str) -> int:
    joined = "\n\n".join(corpus)
    if scheme == "AST":
        return len(extract_ast_bits(joined))
    return len(extract_token_bits(joined))


def build_caches():
    wm_cache = {scheme: {secret: corpus_for_scheme(secret, scheme) for secret in SECRETS}
                for scheme in SCHEMES}
    clean_cache = {attack_name: apply_attack_to_corpus(unwatermarked_corpus(), attack_name)
                   for attack_name in ATTACKS}
    return wm_cache, clean_cache


# ---------------------------------------------------------------------------
# Main robustness sweep (Phase 2 structure, Phase 3 numbers + multichannel col).

def run_main_sweep():
    records = []
    detailed = []
    wm_cache, clean_cache = build_caches()
    for scheme in SCHEMES:
        for attack_name in ATTACKS:
            wm_detected, clean_detected = [], []
            wm_rates, clean_rates = [], []
            correctness, feature_counts = [], []
            mc_detected = []
            attacked_clean = clean_cache[attack_name]

            for secret in SECRETS:
                wm = wm_cache[scheme][secret]
                attacked_wm = apply_attack_to_corpus(wm, attack_name)

                correctness.append(check_correctness(attacked_wm))
                res_wm = detect_corpus(attacked_wm, secret, scheme)
                res_clean = detect_corpus(attacked_clean, secret, scheme)
                wm_detected.append(res_wm.detected)
                clean_detected.append(res_clean.detected)
                wm_rates.append(res_wm.match_rate)
                clean_rates.append(res_clean.match_rate)
                feature_counts.append(res_wm.total)

                if scheme == "AST":
                    det_mc, _, _ = detect_corpus_multichannel(attacked_wm, secret)
                    mc_detected.append(det_mc)

                detailed.append({
                    "scheme": scheme, "attack": attack_name, "secret": secret,
                    "wm_detected": res_wm.detected, "wm_matches": res_wm.matches,
                    "wm_total": res_wm.total, "wm_match_rate": res_wm.match_rate,
                    "wm_p_value": res_wm.p_value,
                    "clean_detected": res_clean.detected,
                    "clean_match_rate": res_clean.match_rate,
                    "correct": correctness[-1],
                })

            records.append({
                "scheme": scheme,
                "attack": attack_name,
                "TPR": mean(wm_detected),
                "FPR": mean(clean_detected),
                "avg_wm_match_rate": mean(wm_rates),
                "avg_clean_match_rate": mean(clean_rates),
                "correctness_rate": mean(correctness),
                "avg_feature_count": mean(feature_counts),
                "TPR_multichannel": mean(mc_detected) if mc_detected else "",
            })
    return records, detailed


# ---------------------------------------------------------------------------
# Phase 3 extras: sample-size scaling and per-task feature capacity.

def run_sample_size_scaling(seed: int = 2026):
    rng = random.Random(seed)
    sizes = [1, 2, 3, 5, 8, 12, 16, 20, 22]
    attacks = ["clean", "rename", "combined_weak"]
    rows = []
    for k in sizes:
        for attack_name in attacks:
            tprs = []
            for secret in SECRETS:
                idxs = rng.sample(range(len(TASKS)), k)
                embedder, _ = SCHEMES["AST"]
                wm = [embedder(TASKS[i].code, f"{secret}|task:{i}") for i in idxs]
                attacked = [ATTACKS[attack_name](c) for c in wm]
                # Detect on the chosen subset, with the same per-task salt.
                from watermark import detect_ast_watermark
                m, n = 0, 0
                for j, idx in enumerate(idxs):
                    res = detect_ast_watermark(attacked[j], f"{secret}|task:{idx}")
                    m += res.matches
                    n += res.total
                tprs.append(int(binom_tail(m, n) <= 0.01))
            rows.append({"k": k, "attack": attack_name, "TPR": mean(tprs)})
    return rows


def run_per_task_features():
    """Watermarkable feature counts per task, broken down by feature type."""
    rows = []
    for i, task in enumerate(TASKS):
        bits = extract_ast_bits(task.code)
        counts = {t: 0 for t in FEATURE_TYPES}
        for typ, _ in bits:
            counts[typ] += 1
        rows.append({"task_index": i, "task_name": task.name, "total": len(bits), **counts})
    return rows


# ---------------------------------------------------------------------------
# Plots. Plain matplotlib defaults to keep the look simple.

def plot_main_tpr(records, path: Path):
    attacks = list(ATTACKS.keys())
    x = range(len(attacks))
    width = 0.35
    fig, ax = plt.subplots(figsize=(11, 5))
    ast_tpr = [r["TPR"] for r in records if r["scheme"] == "AST"]
    tok_tpr = [r["TPR"] for r in records if r["scheme"] == "Token"]
    ax.bar([i - width/2 for i in x], ast_tpr, width, label="AST watermark")
    ax.bar([i + width/2 for i in x], tok_tpr, width, label="Token baseline")
    ax.set_xticks(list(x))
    ax.set_xticklabels(attacks, rotation=25, ha="right")
    ax.set_ylim(0, 1.05)
    ax.set_ylabel("True positive rate")
    ax.set_title("Detection under semantics-preserving edits")
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=200)
    plt.close(fig)


def plot_match_rates(records, path: Path):
    attacks = list(ATTACKS.keys())
    fig, ax = plt.subplots(figsize=(11, 5))
    ast_rate = [r["avg_wm_match_rate"] for r in records if r["scheme"] == "AST"]
    tok_rate = [r["avg_wm_match_rate"] for r in records if r["scheme"] == "Token"]
    ax.plot(attacks, ast_rate, marker="o", label="AST watermark")
    ax.plot(attacks, tok_rate, marker="o", label="Token baseline")
    ax.set_ylim(0, 1.05)
    ax.set_ylabel("Average keyed match rate")
    ax.set_title("How much of the hidden signal remains?")
    ax.tick_params(axis="x", rotation=25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=200)
    plt.close(fig)


def plot_multichannel(records, path: Path):
    ast_records = [r for r in records if r["scheme"] == "AST"]
    attacks = [r["attack"] for r in ast_records]
    agg = [r["TPR"] for r in ast_records]
    mc = [r["TPR_multichannel"] for r in ast_records]
    x = range(len(attacks))
    width = 0.35
    fig, ax = plt.subplots(figsize=(11, 5))
    ax.bar([i - width/2 for i in x], agg, width, label="aggregate")
    ax.bar([i + width/2 for i in x], mc, width, label="multi-channel")
    ax.set_xticks(list(x))
    ax.set_xticklabels(attacks, rotation=25, ha="right")
    ax.set_ylim(0, 1.05)
    ax.set_ylabel("True positive rate")
    ax.set_title("Aggregate vs. multi-channel detector (AST watermark)")
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=200)
    plt.close(fig)


def plot_sample_size(rows, path: Path):
    by_attack = {}
    for r in rows:
        by_attack.setdefault(r["attack"], []).append((r["k"], r["TPR"]))
    fig, ax = plt.subplots(figsize=(8, 5))
    for attack, points in by_attack.items():
        points.sort()
        xs = [p[0] for p in points]
        ys = [p[1] for p in points]
        ax.plot(xs, ys, marker="o", label=attack)
    ax.set_xlabel("Corpus size (number of tasks)")
    ax.set_ylabel("True positive rate")
    ax.set_ylim(0, 1.05)
    ax.set_title("TPR vs. corpus size (AST watermark)")
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=200)
    plt.close(fig)


def plot_per_task(rows, path: Path):
    fig, ax = plt.subplots(figsize=(11, 5))
    names = [r["task_name"] for r in rows]
    x = range(len(names))
    bottom = [0] * len(names)
    for label in FEATURE_TYPES:
        vals = [r[label] for r in rows]
        ax.bar(x, vals, bottom=bottom, label=label)
        bottom = [b + v for b, v in zip(bottom, vals)]
    ax.set_xticks(list(x))
    ax.set_xticklabels(names, rotation=60, ha="right", fontsize=8)
    ax.set_ylabel("Watermarkable AST locations")
    ax.set_title("Watermark capacity per benchmark task")
    ax.legend()
    fig.tight_layout()
    fig.savefig(path, dpi=200)
    plt.close(fig)


# ---------------------------------------------------------------------------
# Driver.

def run():
    records, detailed = run_main_sweep()
    sample_rows = run_sample_size_scaling()
    per_task_rows = run_per_task_features()

    manifest = {
        "num_tasks": len(TASKS),
        "num_keys": NUM_KEYS,
        "attacks": list(ATTACKS.keys()),
        "schemes": list(SCHEMES.keys()),
        "alpha": 0.01,
        "feature_types_ast": list(FEATURE_TYPES),
    }

    with open(RESULTS / "final_results.json", "w") as f:
        json.dump({"manifest": manifest, "summary": records,
                   "sample_size": sample_rows, "per_task": per_task_rows,
                   "detailed": detailed}, f, indent=2)

    with open(RESULTS / "final_summary.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(records[0].keys()))
        w.writeheader()
        w.writerows(records)

    with open(RESULTS / "sample_size.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["k", "attack", "TPR"])
        w.writeheader()
        w.writerows(sample_rows)

    with open(RESULTS / "per_task_features.csv", "w", newline="") as f:
        w = csv.DictWriter(f, fieldnames=["task_index", "task_name", "total", *FEATURE_TYPES])
        w.writeheader()
        w.writerows(per_task_rows)

    plot_main_tpr(records,    RESULTS / "final_tpr_by_attack.png")
    plot_match_rates(records, RESULTS / "final_match_rates.png")
    plot_multichannel(records, RESULTS / "final_multichannel.png")
    plot_sample_size(sample_rows, RESULTS / "final_sample_size.png")
    plot_per_task(per_task_rows, RESULTS / "final_per_task_features.png")

    print("Wrote final_summary.csv, sample_size.csv, per_task_features.csv,")
    print("final_results.json, and 5 PNG figures in results/.")


if __name__ == "__main__":
    run()
