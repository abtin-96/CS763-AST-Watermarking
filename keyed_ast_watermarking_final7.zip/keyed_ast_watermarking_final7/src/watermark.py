"""Keyed AST watermark and token-name baseline for Python code."""
from __future__ import annotations

import ast
import hashlib
import math
from dataclasses import dataclass


ALPHA = 0.01
FEATURE_TYPES = (
    "cmp_dir",
    "const_side",
    "augassign",
    "in_container",
    "return_ternary",
    "return_bool",
    "neq_form",
)


def keyed_bit(secret: str, label: str) -> int:
    h = hashlib.sha256((secret + "|" + label).encode()).digest()
    return h[0] & 1


def binom_tail(k: int, n: int, p: float = 0.5) -> float:
    """Upper tail for Binomial(n, 1/2). Exact for n <= 60, normal-approx otherwise."""
    if n <= 0:
        return 1.0
    if n <= 60:
        return sum(math.comb(n, i) * (0.5 ** n) for i in range(k, n + 1))
    mean = n / 2.0
    sd = math.sqrt(n / 4.0)
    z = (k - 0.5 - mean) / sd
    return 0.5 * math.erfc(z / math.sqrt(2.0))


@dataclass
class DetectionResult:
    matches: int
    total: int
    match_rate: float
    p_value: float
    detected: bool


def _copy_location(new_node: ast.AST, old_node: ast.AST) -> ast.AST:
    return ast.copy_location(new_node, old_node)


def _reverse_cmp(op: ast.cmpop) -> ast.cmpop:
    if isinstance(op, ast.Lt):
        return ast.Gt()
    if isinstance(op, ast.Gt):
        return ast.Lt()
    if isinstance(op, ast.LtE):
        return ast.GtE()
    if isinstance(op, ast.GtE):
        return ast.LtE()
    return op


def _as_lt_family(op, left, right):
    if isinstance(op, (ast.Lt, ast.LtE)):
        return left, op, right
    if isinstance(op, (ast.Gt, ast.GtE)):
        return right, _reverse_cmp(op), left
    return None


def _as_gt_family(op, left, right):
    if isinstance(op, (ast.Gt, ast.GtE)):
        return left, op, right
    if isinstance(op, (ast.Lt, ast.LtE)):
        return right, _reverse_cmp(op), left
    return None


def _is_const(node: ast.AST) -> bool:
    return isinstance(node, ast.Constant)


def _same_name(left: ast.expr, right: ast.expr) -> bool:
    return isinstance(left, ast.Name) and isinstance(right, ast.Name) and left.id == right.id


def _op_for_aug(op: ast.operator):
    if isinstance(op, ast.Add):
        return ast.Add
    if isinstance(op, ast.Sub):
        return ast.Sub
    if isinstance(op, ast.Mult):
        return ast.Mult
    return None


def _pure_literal_container(node: ast.AST) -> bool:
    return isinstance(node, (ast.List, ast.Tuple)) and all(isinstance(e, ast.Constant) for e in node.elts)


def _simple_return_pair(node: ast.If):
    if len(node.body) != 1 or len(node.orelse) != 1:
        return None
    if not isinstance(node.body[0], ast.Return) or not isinstance(node.orelse[0], ast.Return):
        return None
    left = node.body[0].value
    right = node.orelse[0].value
    if left is None or right is None:
        return None
    return node.test, left, right


def _bool_return_form(node: ast.Return) -> tuple[int, bool] | None:
    value = node.value
    if isinstance(value, ast.Constant) and isinstance(value.value, bool):
        return 0, value.value
    if (
        isinstance(value, ast.UnaryOp)
        and isinstance(value.op, ast.Not)
        and isinstance(value.operand, ast.Constant)
        and isinstance(value.operand.value, bool)
    ):
        return 1, (not value.operand.value)
    return None


def _make_bool_return(out_value: bool, bit: int) -> ast.Return:
    if bit == 0:
        return ast.Return(value=ast.Constant(value=out_value))
    return ast.Return(value=ast.UnaryOp(op=ast.Not(), operand=ast.Constant(value=(not out_value))))


def _neq_form_bit(node: ast.AST) -> int | None:
    if (
        isinstance(node, ast.Compare)
        and len(node.ops) == 1
        and len(node.comparators) == 1
        and isinstance(node.ops[0], ast.NotEq)
        and not _is_const(node.left)
        and not _is_const(node.comparators[0])
    ):
        return 0
    if (
        isinstance(node, ast.UnaryOp)
        and isinstance(node.op, ast.Not)
        and isinstance(node.operand, ast.Compare)
        and len(node.operand.ops) == 1
        and len(node.operand.comparators) == 1
        and isinstance(node.operand.ops[0], ast.Eq)
        and not _is_const(node.operand.left)
        and not _is_const(node.operand.comparators[0])
    ):
        return 1
    return None


class ASTWatermarker(ast.NodeTransformer):
    """Embed a keyed watermark using small semantics-preserving AST choices."""

    def __init__(self, secret: str):
        self.secret = secret
        self.counts = {t: 0 for t in FEATURE_TYPES}

    def _target(self, typ: str) -> int:
        idx = self.counts[typ]
        self.counts[typ] += 1
        return keyed_bit(self.secret, f"ast:{typ}:{idx}")

    def visit_If(self, node: ast.If) -> ast.AST:
        pair = _simple_return_pair(node)
        if pair is not None:
            test, left, right = pair
            target = self._target("return_ternary")
            if target == 1:
                out = ast.Return(value=ast.IfExp(test=test, body=left, orelse=right))
                out.value.test = self.visit(out.value.test)
                out.value.body = self.visit(out.value.body)
                out.value.orelse = self.visit(out.value.orelse)
                return _copy_location(out, node)
            node.test = self.visit(test)
            node.body[0].value = self.visit(left)
            node.orelse[0].value = self.visit(right)
            return node
        self.generic_visit(node)
        return node

    def visit_Return(self, node: ast.Return) -> ast.AST:
        form = _bool_return_form(node)
        if form is not None:
            _, out_value = form
            target = self._target("return_bool")
            out = _make_bool_return(out_value, target)
            return _copy_location(out, node)

        if isinstance(node.value, ast.IfExp):
            target = self._target("return_ternary")
            if target == 0:
                out = ast.If(
                    test=node.value.test,
                    body=[ast.Return(value=node.value.body)],
                    orelse=[ast.Return(value=node.value.orelse)],
                )
                out.test = self.visit(out.test)
                out.body[0].value = self.visit(out.body[0].value)
                out.orelse[0].value = self.visit(out.orelse[0].value)
                return _copy_location(out, node)
            node.value.test = self.visit(node.value.test)
            node.value.body = self.visit(node.value.body)
            node.value.orelse = self.visit(node.value.orelse)
            return node

        self.generic_visit(node)
        return node

    def visit_UnaryOp(self, node: ast.UnaryOp) -> ast.AST:
        bit = _neq_form_bit(node)
        if bit == 1:
            target = self._target("neq_form")
            if target == 0:
                cmp = node.operand
                out = ast.Compare(left=cmp.left, ops=[ast.NotEq()], comparators=cmp.comparators)
                out.left = self.visit(out.left)
                out.comparators = [self.visit(c) for c in out.comparators]
                return _copy_location(out, node)
        self.generic_visit(node)
        return node

    def visit_Compare(self, node: ast.Compare) -> ast.AST:
        if len(node.ops) == 1 and len(node.comparators) == 1:
            left, op, right = node.left, node.ops[0], node.comparators[0]
            if isinstance(op, (ast.In, ast.NotIn)) and _pure_literal_container(right):
                target = self._target("in_container")
                if target == 0 and not isinstance(right, ast.Tuple):
                    node.comparators[0] = _copy_location(ast.Tuple(elts=list(right.elts), ctx=ast.Load()), right)
                elif target == 1 and not isinstance(right, ast.List):
                    node.comparators[0] = _copy_location(ast.List(elts=list(right.elts), ctx=ast.Load()), right)
            elif isinstance(op, ast.NotEq) and not _is_const(left) and not _is_const(right):
                target = self._target("neq_form")
                if target == 1:
                    out = ast.UnaryOp(
                        op=ast.Not(),
                        operand=ast.Compare(left=left, ops=[ast.Eq()], comparators=[right]),
                    )
                    out.operand.left = self.visit(out.operand.left)
                    out.operand.comparators = [self.visit(c) for c in out.operand.comparators]
                    return _copy_location(out, node)
            elif isinstance(op, (ast.Eq, ast.NotEq)) and (_is_const(left) ^ _is_const(right)):
                target = self._target("const_side")
                const_left = _is_const(left)
                if (target == 1 and not const_left) or (target == 0 and const_left):
                    node.left, node.comparators[0] = node.comparators[0], node.left
            elif isinstance(op, (ast.Lt, ast.LtE, ast.Gt, ast.GtE)):
                target = self._target("cmp_dir")
                triple = _as_lt_family(op, left, right) if target == 0 else _as_gt_family(op, left, right)
                if triple is not None:
                    node.left, node.ops[0], node.comparators[0] = triple
        self.generic_visit(node)
        return node

    def visit_Assign(self, node: ast.Assign) -> ast.AST:
        if (
            len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
            and isinstance(node.value, ast.BinOp)
            and _op_for_aug(node.value.op) is not None
            and _same_name(node.targets[0], node.value.left)
        ):
            target = self._target("augassign")
            if target == 1:
                aug = ast.AugAssign(target=node.targets[0], op=node.value.op, value=node.value.right)
                self.generic_visit(aug)
                return _copy_location(aug, node)
        self.generic_visit(node)
        return node

    def visit_AugAssign(self, node: ast.AugAssign) -> ast.AST:
        if isinstance(node.target, ast.Name) and _op_for_aug(node.op) is not None:
            target = self._target("augassign")
            if target == 0:
                lhs = ast.Name(id=node.target.id, ctx=ast.Load())
                rhs = ast.BinOp(left=lhs, op=node.op, right=node.value)
                out = ast.Assign(targets=[node.target], value=rhs)
                self.generic_visit(out)
                return _copy_location(out, node)
        self.generic_visit(node)
        return node


class ASTFeatureExtractor(ast.NodeVisitor):
    def __init__(self):
        self.bits: list[tuple[str, int]] = []

    def visit_If(self, node: ast.If) -> None:
        pair = _simple_return_pair(node)
        if pair is not None:
            self.bits.append(("return_ternary", 0))
            test, left, right = pair
            self.visit(test)
            self.visit(left)
            self.visit(right)
            return
        self.generic_visit(node)

    def visit_Return(self, node: ast.Return) -> None:
        form = _bool_return_form(node)
        if form is not None:
            bit, _ = form
            self.bits.append(("return_bool", bit))
            return
        if isinstance(node.value, ast.IfExp):
            self.bits.append(("return_ternary", 1))
            self.visit(node.value.test)
            self.visit(node.value.body)
            self.visit(node.value.orelse)
            return
        self.generic_visit(node)

    def visit_UnaryOp(self, node: ast.UnaryOp) -> None:
        bit = _neq_form_bit(node)
        if bit == 1:
            self.bits.append(("neq_form", 1))
            self.visit(node.operand.left)
            self.visit(node.operand.comparators[0])
            return
        self.generic_visit(node)

    def visit_Compare(self, node: ast.Compare) -> None:
        if len(node.ops) == 1 and len(node.comparators) == 1:
            left, op, right = node.left, node.ops[0], node.comparators[0]
            if isinstance(op, (ast.In, ast.NotIn)) and _pure_literal_container(right):
                self.bits.append(("in_container", 1 if isinstance(right, ast.List) else 0))
            elif isinstance(op, ast.NotEq) and not _is_const(left) and not _is_const(right):
                self.bits.append(("neq_form", 0))
            elif isinstance(op, (ast.Eq, ast.NotEq)) and (_is_const(left) ^ _is_const(right)):
                self.bits.append(("const_side", 1 if _is_const(left) else 0))
            elif isinstance(op, (ast.Lt, ast.LtE, ast.Gt, ast.GtE)):
                self.bits.append(("cmp_dir", 1 if isinstance(op, (ast.Gt, ast.GtE)) else 0))
        self.generic_visit(node)

    def visit_Assign(self, node: ast.Assign) -> None:
        if (
            len(node.targets) == 1
            and isinstance(node.targets[0], ast.Name)
            and isinstance(node.value, ast.BinOp)
            and _op_for_aug(node.value.op) is not None
            and _same_name(node.targets[0], node.value.left)
        ):
            self.bits.append(("augassign", 0))
        self.generic_visit(node)

    def visit_AugAssign(self, node: ast.AugAssign) -> None:
        if isinstance(node.target, ast.Name) and _op_for_aug(node.op) is not None:
            self.bits.append(("augassign", 1))
        self.generic_visit(node)


def embed_ast_watermark(code: str, secret: str) -> str:
    tree = ast.parse(code)
    marked = ASTWatermarker(secret).visit(tree)
    ast.fix_missing_locations(marked)
    return ast.unparse(marked)


def extract_ast_bits(code: str) -> list[tuple[str, int]]:
    ex = ASTFeatureExtractor()
    ex.visit(ast.parse(code))
    return ex.bits


def detect_ast_watermark(code: str, secret: str, alpha: float = ALPHA) -> DetectionResult:
    bits = extract_ast_bits(code)
    type_counts: dict[str, int] = {}
    matches = 0
    for typ, bit in bits:
        idx = type_counts.get(typ, 0)
        type_counts[typ] = idx + 1
        matches += int(bit == keyed_bit(secret, f"ast:{typ}:{idx}"))
    total = len(bits)
    p = binom_tail(matches, total)
    return DetectionResult(matches, total, matches / total if total else 0.0, p, p <= alpha)


def detect_ast_watermark_multichannel(code: str, secret: str, alpha: float = ALPHA) -> dict:
    bits = extract_ast_bits(code)
    matches_by_type = {t: 0 for t in FEATURE_TYPES}
    total_by_type = {t: 0 for t in FEATURE_TYPES}
    type_counts: dict[str, int] = {}
    agg_matches = 0
    for typ, bit in bits:
        idx = type_counts.get(typ, 0)
        type_counts[typ] = idx + 1
        m = int(bit == keyed_bit(secret, f"ast:{typ}:{idx}"))
        matches_by_type[typ] += m
        total_by_type[typ] += 1
        agg_matches += m

    total = len(bits)
    aggregate_p = binom_tail(agg_matches, total)
    aggregate_detected = aggregate_p <= alpha

    k = max(sum(1 for t in FEATURE_TYPES if total_by_type[t] > 0), 1)
    per_channel = {}
    any_channel_detected = False
    for typ in FEATURE_TYPES:
        n, m = total_by_type[typ], matches_by_type[typ]
        p = binom_tail(m, n) if n > 0 else 1.0
        detected = (n > 0) and (p <= alpha / k)
        per_channel[typ] = {"matches": m, "total": n, "p_value": p, "detected": detected}
        any_channel_detected = any_channel_detected or detected

    return {
        "aggregate_matches": agg_matches,
        "aggregate_total": total,
        "aggregate_p_value": aggregate_p,
        "aggregate_detected": aggregate_detected,
        "per_channel": per_channel,
        "multichannel_detected": aggregate_detected or any_channel_detected,
    }


class LocalNameCollector(ast.NodeVisitor):
    def __init__(self):
        self.names: list[str] = []
        self.seen: set[str] = set()

    def _add(self, name: str) -> None:
        if name not in self.seen and name != "solve":
            self.seen.add(name)
            self.names.append(name)

    def visit_arg(self, node: ast.arg) -> None:
        self._add(node.arg)

    def visit_Name(self, node: ast.Name) -> None:
        if isinstance(node.ctx, ast.Store):
            self._add(node.id)


class RenameTransformer(ast.NodeTransformer):
    def __init__(self, mapping: dict[str, str]):
        self.mapping = mapping

    def visit_arg(self, node: ast.arg) -> ast.AST:
        if node.arg in self.mapping:
            node.arg = self.mapping[node.arg]
        return node

    def visit_Name(self, node: ast.Name) -> ast.AST:
        if node.id in self.mapping:
            node.id = self.mapping[node.id]
        return node


def embed_token_watermark(code: str, secret: str) -> str:
    tree = ast.parse(code)
    coll = LocalNameCollector()
    coll.visit(tree)
    mapping: dict[str, str] = {}
    for idx, name in enumerate(coll.names):
        bit = keyed_bit(secret, f"tok:name:{idx}")
        prefix = "ax" if bit == 0 else "by"
        mapping[name] = f"{prefix}_{idx}_{name}"
    marked = RenameTransformer(mapping).visit(tree)
    ast.fix_missing_locations(marked)
    return ast.unparse(marked)


def extract_token_bits(code: str) -> list[int]:
    tree = ast.parse(code)
    coll = LocalNameCollector()
    coll.visit(tree)
    bits: list[int] = []
    for name in coll.names:
        if name.startswith("ax_"):
            bits.append(0)
        elif name.startswith("by_"):
            bits.append(1)
    return bits


def detect_token_watermark(code: str, secret: str, alpha: float = ALPHA) -> DetectionResult:
    bits = extract_token_bits(code)
    matches = 0
    for idx, bit in enumerate(bits):
        matches += int(bit == keyed_bit(secret, f"tok:name:{idx}"))
    total = len(bits)
    p = binom_tail(matches, total)
    return DetectionResult(matches, total, matches / total if total else 0.0, p, p <= alpha)
