"""Unit tests for the keyed AST watermarking prototype."""
import sys
import unittest
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT / "src"))

from attacks import (  # noqa: E402
    combined_strong, combined_weak, format_code, insert_dead_code,
    normalize_ast_features, normalize_cmp_only, normalize_six_of_seven,
    rename_variables,
)
from benchmark import TASKS, run_task_tests  # noqa: E402
from watermark import (  # noqa: E402
    detect_ast_watermark, detect_ast_watermark_multichannel,
    detect_token_watermark, embed_ast_watermark, embed_token_watermark,
    extract_ast_bits, keyed_bit,
)


SECRET = "test-secret-0001"


class KeyedBitTest(unittest.TestCase):
    def test_deterministic(self):
        self.assertEqual(keyed_bit("s", "a"), keyed_bit("s", "a"))

    def test_different_secrets_differ(self):
        labels = [f"ast:cmp_dir:{i}" for i in range(50)]
        b0 = [keyed_bit("secret-A", l) for l in labels]
        b1 = [keyed_bit("secret-B", l) for l in labels]
        self.assertNotEqual(b0, b1)


class CleanRoundTripTest(unittest.TestCase):
    def test_ast_clean_detects_perfectly(self):
        for i, task in enumerate(TASKS):
            wm = embed_ast_watermark(task.code, f"{SECRET}|task:{i}")
            res = detect_ast_watermark(wm, f"{SECRET}|task:{i}")
            self.assertEqual(res.matches, res.total, msg=task.name)
            self.assertTrue(res.detected or res.total < 6, msg=task.name)

    def test_ast_correctness_preserved(self):
        for i, task in enumerate(TASKS):
            wm = embed_ast_watermark(task.code, f"{SECRET}|task:{i}")
            self.assertTrue(run_task_tests(wm, task), msg=task.name)


class SurfaceAttackTest(unittest.TestCase):
    def _check(self, attack):
        for i, task in enumerate(TASKS):
            wm = embed_ast_watermark(task.code, f"{SECRET}|task:{i}")
            attacked = attack(wm)
            self.assertTrue(run_task_tests(attacked, task), msg=task.name)
            res = detect_ast_watermark(attacked, f"{SECRET}|task:{i}")
            self.assertEqual(res.match_rate, 1.0, msg=f"{attack.__name__} / {task.name}")

    def test_format(self):
        self._check(format_code)

    def test_rename(self):
        self._check(rename_variables)

    def test_dead_code(self):
        self._check(insert_dead_code)

    def test_combined_weak(self):
        self._check(combined_weak)


class AdaptiveAttackTest(unittest.TestCase):
    def test_ast_normalize_drops_match_rate(self):
        rates = []
        for i, task in enumerate(TASKS):
            wm = embed_ast_watermark(task.code, f"{SECRET}|task:{i}")
            attacked = normalize_ast_features(wm)
            res = detect_ast_watermark(attacked, f"{SECRET}|task:{i}")
            if res.total > 0:
                rates.append(res.match_rate)
        avg = sum(rates) / len(rates)
        self.assertLess(avg, 0.75, msg=f"average match rate after ast_normalize: {avg}")


class TokenBaselineTest(unittest.TestCase):
    def test_token_clean_detects(self):
        wm = embed_token_watermark(TASKS[0].code, SECRET)
        res = detect_token_watermark(wm, SECRET)
        self.assertEqual(res.match_rate, 1.0)

    def test_token_breaks_under_rename(self):
        wm = embed_token_watermark(TASKS[0].code, SECRET)
        attacked = rename_variables(wm)
        res = detect_token_watermark(attacked, SECRET)
        self.assertEqual(res.matches, 0)


class MultiChannelTest(unittest.TestCase):
    def test_multichannel_returns_per_channel(self):
        wm = embed_ast_watermark(TASKS[0].code, f"{SECRET}|task:0")
        res = detect_ast_watermark_multichannel(wm, f"{SECRET}|task:0")
        self.assertIn("per_channel", res)
        self.assertIn("aggregate_detected", res)

    def test_partial_normalization_keeps_other_channels(self):
        for i, task in enumerate(TASKS):
            bits = extract_ast_bits(task.code)
            types = {t for t, _ in bits}
            if "cmp_dir" not in types or len(types) < 2:
                continue
            wm = embed_ast_watermark(task.code, f"{SECRET}|task:{i}")
            attacked = normalize_cmp_only(wm)
            res = detect_ast_watermark_multichannel(attacked, f"{SECRET}|task:{i}")
            others = [t for t, v in res["per_channel"].items() if t != "cmp_dir" and v["total"] > 0]
            for t in others:
                self.assertEqual(res["per_channel"][t]["matches"], res["per_channel"][t]["total"])
            return
        self.skipTest("no benchmark task has cmp_dir + another feature")


class NewFeatureTest(unittest.TestCase):
    def test_return_ternary_detected(self):
        code = "def solve(x):\n    if x > 0:\n        return 1\n    else:\n        return 2\n"
        wm = embed_ast_watermark(code, SECRET)
        bits = [t for t, _ in extract_ast_bits(wm)]
        self.assertIn("return_ternary", bits)

    def test_return_bool_detected(self):
        code = "def solve(x):\n    if x:\n        return True\n    return False\n"
        wm = embed_ast_watermark(code, SECRET)
        bits = [t for t, _ in extract_ast_bits(wm)]
        self.assertIn("return_bool", bits)

    def test_neq_form_detected(self):
        code = "def solve(a, b):\n    return a != b\n"
        wm = embed_ast_watermark(code, SECRET)
        bits = [t for t, _ in extract_ast_bits(wm)]
        self.assertIn("neq_form", bits)


class CounterOrderingTest(unittest.TestCase):
    def test_nested_compare_indices_agree(self):
        code = "def solve(a, b, c):\n    return (a < b) > c\n"
        wm = embed_ast_watermark(code, SECRET)
        res = detect_ast_watermark(wm, SECRET)
        self.assertEqual(res.matches, res.total)


class CombinedStrongTest(unittest.TestCase):
    def test_combined_strong_drops_to_chance(self):
        m, n = 0, 0
        for i, task in enumerate(TASKS):
            wm = embed_ast_watermark(task.code, f"{SECRET}|task:{i}")
            attacked = combined_strong(wm)
            res = detect_ast_watermark(attacked, f"{SECRET}|task:{i}")
            m += res.matches
            n += res.total
        rate = m / n
        self.assertLess(abs(rate - 0.5), 0.2)

    def test_six_of_seven_leaves_signal(self):
        m, n = 0, 0
        for i, task in enumerate(TASKS):
            wm = embed_ast_watermark(task.code, f"{SECRET}|task:{i}")
            attacked = normalize_six_of_seven(wm)
            res = detect_ast_watermark(attacked, f"{SECRET}|task:{i}")
            m += res.matches
            n += res.total
        self.assertGreater(m / n, 0.5)


if __name__ == "__main__":
    unittest.main(verbosity=2)
